/*
 programmer: patrick kelley, nick lyons
 Version 0.1
 description: this is a temperate-aware process/task scheduler for a gpio
 currently it takes value from hotspot, and returns the name of the coolest available corer
 */
package shcedulertest;

import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author prkel
 */
public class Shcedulertest {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        String outfilename = "data.txt";
        File outfile = new File(outfilename);
        List<node> nodes = new ArrayList<>();
        node temp = new node();
        nodes.add(temp);
        node lowest;
        Double lowesttemp;
        String status = " ";

        checkInput(); //check input file format, exits status 1 if format error found

        getInput(nodes); //load new data fomr hotspot file
        writeout(nodes); //write out data to database file
        lowest = findlowest(nodes);
        lowesttemp = Double.parseDouble(lowest.getTemp());

        if (lowesttemp < 338) {
            status = "normal";
        }

        if (lowesttemp > 338 && lowesttemp < 353) {
            status = "high";
        }

        if (lowesttemp > 353) {
            status = "extreme";
        }

        System.out.print(status + " ");
        System.out.println(lowest.getName());
    }

//read in the input file
    static void getInput(List nodes) throws IOException {
        String infilename = "hotspot_output.txt";
        File infile = new File(infilename);
        Scanner infileScanner = new Scanner(infile);
        while (infileScanner.hasNext()) {
            String token = infileScanner.next();
            if (token.contains("node")) { //if it contains 'node' we care calling that a core
//         System.out.println("found a node");  //just a test flag
                node temp = new node();
                temp.setname(token);
                temp.settemp(infileScanner.next());
                nodes.add(temp);
            }
//     System.out.println(token);
        }
        infileScanner.close();

    }

//write the database file
    static void writeout(List<node> nodes) throws IOException {
        String outfilename = "currentdata";
        File outfile = new File(outfilename);
        PrintWriter outfilePW = new PrintWriter(outfile);
        Iterator nodeitr = nodes.iterator();
        for (int i = 1; i < nodes.size(); i++) {
            outfilePW.print(nodes.get(i).getName() + " ");
            outfilePW.println(nodes.get(i).getTemp());
        }

        outfilePW.close();
    }

    static node findlowest(List<node> nodes) {
        int lowestindex = 1;
        for (int i = 1; i < nodes.size(); i++) {
            if (Double.parseDouble(nodes.get(lowestindex).getTemp()) > Double.parseDouble(nodes.get(i).getTemp())) {
                lowestindex = i;
            }
        }
        return nodes.get(lowestindex);
    }

    static void checkInput() throws IOException {
        String infilename = "hotspot_output.txt";
        File infile = new File(infilename);
        Scanner infileScanner = new Scanner(infile);
        String temp = " ";

        double check = 0;
        int cnt = 0;
        infileScanner.nextLine(); //throw out the first line, it contains the colum header, two strings

        while (infileScanner.hasNext()) {
            temp = infileScanner.next(); //grab the first token, should be name of a thing
            temp = infileScanner.next(); //this should be a float, we need to check this
            cnt++;

            try {
                check = Float.parseFloat(temp);
            } catch (NumberFormatException e) {
                // its its not a float, catch this and flag
                System.out.println("file error found on line: " + (cnt + 1));
                infileScanner.close();
                System.exit(1);
            }

        }
        infileScanner.close();

    }

}
  //check for file content validity --done

//save the current state -done
//calculate change  based on input
//check for temrpature flags, -not needed, flag is display in console. 

