/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shcedulertest;

/**
 *
 * @author prkel
 */
public class node implements Cloneable{
    
    String nodename;
    String nodetemp;
    
    
    void node (){
        
        
    }
    
    void setname (String newname){
        nodename = newname;
    }
    
    void settemp (String newtemp){
        nodetemp = newtemp;
    }
    
    String getName (){
        return nodename;
    }
    
    String getTemp(){
        return nodetemp;
    }
    
    node c (){
        node temp = new node();
        temp.settemp(nodetemp);
        temp.setname(nodename);
        return temp;
    }
}
